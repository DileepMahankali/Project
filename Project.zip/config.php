<?php

$conn = mysqli_connect('localhost','root','@Muni2dileep','dileep') or die('connection failed');

?>